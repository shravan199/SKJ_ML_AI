This zip archive contains data files from Cricsheet in JSON format. This
archive contains 9 recently added male matches.


The JSON data files contained in this zip file are version 1.0.0, and 1.1.0
files. You can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/recently_added_2_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2023-03-19 - international - ODI - male - 1348657 - India vs Australia
2023-03-18 - international - ODI - male - 1339602 - West Indies vs South Africa
2023-03-18 - club - PSL - male - 1354957 - Lahore Qalandars vs Multan Sultans
2023-03-18 - international - ODI - male - 1355717 - Bangladesh vs Ireland
2023-03-17 - international - ODI - male - 1348656 - Australia vs India
2023-03-17 - club - PSL - male - 1354956 - Peshawar Zalmi vs Lahore Qalandars
2023-03-14 - club - SSH - male - 1322423 - Tasmania vs Queensland
2023-03-14 - club - SSH - male - 1322424 - New South Wales vs South Australia
2023-03-14 - club - SSH - male - 1322425 - Western Australia vs Victoria
